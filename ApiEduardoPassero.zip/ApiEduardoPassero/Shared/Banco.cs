using System.ComponentModel.DataAnnotations;

namespace ApiEduardoPassero.Shared
{
    public class Banco
    {
        [Required]
        public int Id { get; set; }

        [Required(ErrorMessage = "O nome do banco � obrigat�rio")]
        public string Nome { get; set; } = string.Empty;

        [Required(ErrorMessage = "O c�digo � obrigat�rio")]
        public int Codigo { get; set; }

        [Required(ErrorMessage = "Insira o percentual de juro")]
        public decimal Juro { get; set; }
    }
}