using System.ComponentModel.DataAnnotations;

namespace ApiEduardoPassero.Shared
{
    public class BancoSelectDto
    {
        public int Id { get; set; }
        public string Nome { get; set; } = string.Empty;
    }
}