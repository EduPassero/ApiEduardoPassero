using System.ComponentModel.DataAnnotations;

namespace ApiEduardoPassero.Shared
{
    public class BancoDto
    {
        public string Nome { get; set; } = string.Empty;

        public int Codigo { get; set; }

        public decimal Juro { get; set; }
    }
}