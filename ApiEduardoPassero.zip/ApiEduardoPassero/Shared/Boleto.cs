using System.ComponentModel.DataAnnotations;

namespace ApiEduardoPassero.Shared
{
    public class Boleto
    {
        [Required]
        public int Id { get; set; }

        [Required(ErrorMessage = "Escolha um banco")]
        public int BancoId { get; set; }

        [Required(ErrorMessage = "O CPF/CNPJ do pagador � obrigat�rio")]
        public long CpfPagador { get; set; }

        [Required(ErrorMessage = "O nome do pagador � obrigat�rio")]
        public string NomePagador { get; set; } = string.Empty;

        [Required(ErrorMessage = "O CPF/CNPJ do benefici�rio � obrigat�rio")]
        public long CpfBeneficiario { get; set; }

        [Required(ErrorMessage = "O nome do benefici�rio � obrigat�rio")]
        public string NomeBenecifiario { get; set; } = string.Empty;

        [Required(ErrorMessage = "Qual o valor do boleto?")]
        public decimal Valor { get; set; }

        [Required(ErrorMessage = "Qual a data de vencimento?")]
        public DateTime Vencimento { get; set; }

        public string Observaoces { get; set; } = string.Empty;
    }
}