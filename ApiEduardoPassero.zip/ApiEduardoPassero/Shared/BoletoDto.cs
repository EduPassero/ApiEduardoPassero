using System.ComponentModel.DataAnnotations;

namespace ApiEduardoPassero.Shared
{
    public class BoletoDto
    {
        public int BancoId { get; set; }

        public string NomePagador { get; set; } = string.Empty;

        public string NomeBenecifiario { get; set; } = string.Empty;

        public decimal Valor { get; set; }

        public DateTime Vencimento { get; set; }
    }
}