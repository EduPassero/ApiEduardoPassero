using System.ComponentModel.DataAnnotations;

namespace ApiEduardoPassero.Shared
{
    public class BancoJuroDto
    {
        public decimal Juro { get; set; }
    }
}