using Microsoft.AspNetCore.Mvc;
using ApiEduardoPassero.Server.Data;
using ApiEduardoPassero.Shared;
using Microsoft.EntityFrameworkCore;
using AutoMapper;

namespace ApiEduardoPassero.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class BoletoController : ControllerBase
    {
        private readonly DataContext _context;
		private readonly IMapper _mapper;
		public BoletoController(DataContext context, IMapper mapper)
        {
            _context = context;
			_mapper = mapper;
		}

        [HttpGet("{id}")]
        public async Task<ActionResult<BoletoDto>> GetBoleto(int id)
        {
            try
            {
                var boleto = await _context.Boletos.FindAsync(id);
				if (boleto == null)
				{
					return NotFound();
				}

				_mapper.Map<BoletoDto>(boleto);
                return Ok(boleto);
            }
            catch (Exception ex)
            {
                return StatusCode(500, "Ocorreu um erro interno. Entre em contato com o suporte. " + ex);
            }
        }

        [HttpPost]
        public async Task<ActionResult<List<Boleto>>> PostBoleto(Boleto boleto)
        {
            try
            {
                _context.Boletos.Add(boleto);
                await _context.SaveChangesAsync();
                return Ok(await _context.Boletos.ToListAsync());
            }
            catch (Exception ex)
            {
                return StatusCode(500, "Ocorreu um erro interno. Entre em contato com o suporte. " + ex);
            }
        }
    }
}