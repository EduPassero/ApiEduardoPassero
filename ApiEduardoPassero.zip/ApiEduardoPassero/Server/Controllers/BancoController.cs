using Microsoft.AspNetCore.Mvc;
using ApiEduardoPassero.Server.Data;
using ApiEduardoPassero.Shared;
using Microsoft.EntityFrameworkCore;
using AutoMapper;

namespace ApiEduardoPassero.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class BancoController : ControllerBase
    {
        private readonly DataContext _context;
        private readonly IMapper _mapper;

        public BancoController(DataContext context, IMapper mapper)
        {
            _context = context;
            _mapper = mapper;
        }

        [HttpGet("buscabancos")]
        public async Task<ActionResult<List<BancoDto>>> GetBancos()
        {
            try
            {
                var bancos = await _context.Bancos.ToListAsync();
                
                if (bancos == null)
                {
                    return NotFound();
                }
                return Ok(bancos.Select(banco => _mapper.Map<BancoDto>(banco)));
            }
            catch (Exception ex)
            {
                return StatusCode(500, "Ocorreu um erro interno. Entre em contato com o suporte. " + ex);
            }
        }


		[HttpGet("bancoselect")]
        public async Task<ActionResult<List<BancoSelectDto>>> GetBancosSelect()
        {
            try
            {
                var bancos = await _context.Bancos.ToListAsync();

                if (bancos == null)
                {
                    return NotFound();
                }
                return Ok(bancos.Select(banco => _mapper.Map<BancoSelectDto>(banco)));
            }
            catch (Exception ex)
            {
                return StatusCode(500, "Ocorreu um erro interno. Entre em contato com o suporte. " + ex);
            }
        }

        [HttpGet("juro/{id}")]
        public async Task<ActionResult<BancoJuroDto>> GetJuroBanco(int id)
        {
            try
            {
                var banco = await _context.Bancos.FindAsync(id);

                if (banco == null)
                {
                    return NotFound();
                }
                _mapper.Map<BancoJuroDto>(banco);
                return Ok(banco);
            }
            catch (Exception ex)
            {
                return StatusCode(500, "Ocorreu um erro interno. Entre em contato com o suporte. " + ex);
            }
        }

		[HttpGet("{codigo}")]
		public async Task<ActionResult<BancoDto>> GetBancoPorCodigo(int codigo)
		{
			try
			{
				var banco = await _context.Bancos.Where(b => b.Codigo == codigo).FirstOrDefaultAsync();

				if (banco == null)
				{
					return NotFound();
				}
				_mapper.Map<BancoDto>(banco);
				return Ok(banco);
			}
			catch (Exception ex)
			{
				return StatusCode(500, "Ocorreu um erro interno. Entre em contato com o suporte. " + ex);
			}
		}

		[HttpPost]
        public async Task<ActionResult<List<Banco>>> PostBanco(Banco banco)
        {
            try
            {
                _context.Bancos.Add(banco);
                await _context.SaveChangesAsync();
                return Ok(await _context.Bancos.ToListAsync());
            }
            catch (Exception ex)
            {
                return StatusCode(500, "Ocorreu um erro interno. Entre em contato com o suporte. " + ex);
            }
        }
    }
}