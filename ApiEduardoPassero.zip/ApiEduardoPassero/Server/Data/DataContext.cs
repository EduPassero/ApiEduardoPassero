﻿using ApiEduardoPassero.Shared;
using Microsoft.EntityFrameworkCore;

namespace ApiEduardoPassero.Server.Data
{
    public class DataContext : DbContext
    {
        public DataContext(DbContextOptions<DataContext> options) : base(options)
        {

        }

        public DbSet<Banco> Bancos { get; set; }
        public DbSet<Boleto> Boletos { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Banco>().Property(e => e.Juro).HasColumnType("decimal(18, 2)");
            modelBuilder.Entity<Boleto>().Property(e => e.Valor).HasColumnType("decimal(18, 2)");
        }
    }
}
