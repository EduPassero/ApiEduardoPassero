using AutoMapper;
using ApiEduardoPassero.Shared;

namespace ApiEduardoPassero.Server
{
    public class AutoMapperProfile : Profile
    {
        public AutoMapperProfile()
        {
            CreateMap<Banco, BancoDto>();
            CreateMap<BancoDto, Banco>();
			CreateMap<Banco, BancoSelectDto>();
            CreateMap<Banco, BancoJuroDto>();

            CreateMap<Boleto, BoletoDto>();
		}
    }
}